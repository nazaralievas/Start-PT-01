from django.db import models
from django.contrib.auth.models import User


class Movie(models.Model):
    name = models.CharField(max_length=255)
    name_lower = models.CharField(max_length=255, editable=False)
    genre = models.CharField(max_length=100)
    description = models.TextField()
    poster = models.ImageField(upload_to='posters/')
    
    def save(self, *args, **kwargs):
        self.name_lower = self.name.lower()
        super(Movie, self).save(*args, **kwargs)

    def __str__(self):
        return self.name


class Comment(models.Model):
    movie = models.ForeignKey(Movie, on_delete=models.CASCADE, related_name='comments')
    user = models.ForeignKey(User, on_delete=models.CASCADE, related_name='comments')
    text = models.TextField()
    date_created = models.DateField(auto_now_add=True)

    class Meta:
        ordering = ['-date_created']