from django.urls import path
from .views import *

urlpatterns = [
    path('', movie_list, name='movie_list'),
    path('movie_detail/<int:id>/', movie_detail, name='movie_detail'),
    path('login/', login, name='login'),
    path('logout/', logout, name='logout'),
    path('register/', register, name='register'),
    path('edit_comment/<int:id>/', edit_comment, name='edit_comment'),
    path('delete_comment/<int:id>/', delete_comment, name='delete_comment'),
    path('random_dog/', random_dog, name='random_dog'),
    path('user_profile/<int:id>/', user_profile, name='user_profile'),
]